const express = require('express');
const axios = require('axios');
const app = express();

const PORT = 3000;
const API_KEY = "AIzaSyARLSkqKXssrf46Fba6h5nmjwJD0LXTfa4";

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs');
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.render('index', { response: null });
});

app.post('/chat', async (req, res) => {
    const userInput = req.body.prompt;

    try {
        const response = await axios.post(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`,
            {
                contents: [{
                    role: "user",
                    parts: [{ text: `${userInput}\n\nRespond in clear bullet points.` }]
                }]
            },
            {
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );

        const botReply = response.data.candidates[0].content.parts[0].text;
        res.render('index', { response: botReply });

    } catch (err) {
        console.error(err.response?.data || err.message);
        res.render('index', { response: "❌ Error: Could not reach Gemini API" });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

